#ifndef CLASS_BURGERS
#define CLASS_BURGERS
#include <iostream>
#include <string>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <stdexcept>
#include <math.h>
#include "Model.h"

//Inheritance in order to allow Burger class access the values and functions of Model

class Burgers : public Model{
private:
        
        Model m;
        double* u;
        double* v;
        double* u_temp;
        double* v_temp;
        double r;
        double E;
        
    
    public:
         Burgers(Model m);
        ~Burgers();// Model class destructor#
        void iVelocity();
        void vIntegral();
        void vEnergy();
        void vWrite();
    };

#endif