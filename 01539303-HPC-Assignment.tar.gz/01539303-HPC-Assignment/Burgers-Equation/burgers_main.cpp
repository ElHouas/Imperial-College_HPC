#include <chrono>
#include <iostream>
#include <stdlib.h>

#include "Model.h"
#include "Burgers.h"

using namespace std;

//Linux commnad to compile and run the code
//g++ burgers.cpp -o a
//

int main(int argc, char* argv[]) {

    Model m(argc, argv);
    
    // Call code to initialise the problem here
    
    Burgers B(m);   

    // Call code to perform time integration here
    
    B.iVelocity();
    
    //B.vEnergy();
    
    B.vIntegral();

    // Calculate final energy and write output
    
    B.vEnergy();
    
    B.vWrite();

    return 0;
            }