#include <stdexcept>
#include <iostream>
#include "Model.h"
#include "Burgers.h"
#include <cstdlib>
#include <iomanip>      // std::setprecision



Burgers::Burgers(Model m) {
    
    this-> m = m;
}

//Burgers::Burgers():Model(){}

Burgers::~Burgers(){ // Model class destructor#
    cout << "Burguers class destroyed" << endl;
}


void Burgers::iVelocity(){
            //Velocities u v
            
            u = new double [m.GetNx() * m.GetNy()];
            v = new double [m.GetNx() * m.GetNy()];
            u_temp = new double [m.GetNx() * m.GetNy()];
            v_temp = new double [m.GetNx() * m.GetNy()];
            
            int Nx = m.GetNx();
            int Ny = m.GetNy();
            double dx = m.GetDx();
            double dy = m.GetDy();
            
             for(unsigned i = 0; i < Nx; ++i){
                    
                    for(unsigned j = 0; j < Ny; ++j){
                        
                        r = sqrt( (pow(i*dx- m.GetX0(),2) )  + (pow(j*dy- m.GetY0(),2) ) );
                        
                        if(r<=1){
                            u[i*Nx+j] = 2.0*pow((1-r),4)*((4*r)+1.0);
                           
                            v[i*Nx+j] = 2.0*pow((1-r),4)*((4*r)+1.0);
                        } else {
                            u[i*Nx+j] = 0;
                         
                            v[i*Nx+j] = 0;
                        }
                                                
                        cout.precision(4);
                        cout << u[i*Nx+j] << " ";
                    }
                    cout << endl;
                    
                }
                 cout << endl;
        }
        
      //Time integration
        
void Burgers::vIntegral(){
            
            //Declare derivivatives
            
            double Udx;
            double Udy;
            double Udx_2;
            double Udy_2;
            
            double Vdx;
            double Vdy;
            double Vdx_2;
            double Vdy_2;
            
            //Variables from Model to be used
            
            int Nt = m.GetNt();
            int Nx = m.GetNx();
            int Ny = m.GetNy();
            double dt = m.GetDt();  
            double dx = m.GetDx();
            double dy = m.GetDy();
            double ax = m.GetAx(); 
            double ay = m.GetAy();
            double b = m.GetB();
            double c = m.GetC(); //Kinematic viscosity 
            
            
            for(unsigned n = 0; n < Nt; ++n){
                
                /*Initialize Energy at zero*/
                E = 0;
                
                for(unsigned i = 1; i < Nx; ++i){
                    
                    for(unsigned j = 1; j < Ny; ++j){

                         Udx = (u[i*Nx+j]-u[(i-1)*Nx+j])/dx;
                         Udy = (u[i*Nx+j]-u[i*Nx+(j-1)])/dy;
                        
                         Udx_2 = (u[(i+1)*Nx+j]-2*u[i*Nx+j]+u[(i-1)*Nx+j])/(pow(dx,2));
                         Udy_2 = (u[i*Nx+(j+1)]-2*u[i*Nx+j]+u[i*Nx+(j-1)])/(pow(dy,2));
                         
                         
                         u[i*Nx+j] = u[i*Nx+j] + dt*(c*(Udx_2 + Udy_2) - (ax+b*u[i*Nx+j])*Udx - (ay+b*v[i*Nx+j])*Udy);
                         
                         
                         Vdx = (v[i*Nx+j]-v[(i-1)*Nx+j])/dx;
                         Vdy = (v[i*Nx+j]-v[i*Nx+(j-1)])/dy;
            
                         Vdx_2 = (v[(i+1)*Nx+j]-2*v[i*Nx+j]+v[(i-1)*Nx+j])/(pow(dx,2));
                         Vdy_2 = (v[i*Nx+(j+1)]-2*v[i*Nx+j]+v[i*Nx+(j-1)])/(pow(dy,2));
                         
                         v[i*Nx+j] = v[i*Nx+j] + dt*(c*(Vdx_2 + Vdy_2) - (ax+b*u[i*Nx+j])*Vdx - (ay+b*v[i*Nx+j])*Vdy);
                        
                         E = E + 0.5*(pow(u[i*Nx+j],2) + pow(v[i*Nx+j],2));
                    }
                }
            } 
}
        

void Burgers::vEnergy(){
    
                double Area = m.GetLx()*m.GetLy();
                               
                E = E*Area;
                
                cout << "Energy: " <<E << endl;
        
    }

void Burgers::vWrite(){
            
                ofstream vOut("velocity_field.txt", ios::out | ios::trunc);
                vOut.precision(5);

                for(unsigned i = 0; i < m.GetNx(); ++i){
                    
                    for(unsigned j = 0; j < m.GetNy(); ++j){
                        vOut << setw(15) << i*m.GetDx(); 
                        vOut << setw(20) << j*m.GetDy() ;
                        vOut << setw(20) << u[i*m.GetNx()+j] ;
                        vOut << setw(20) << v[i*m.GetNx()+j] << endl; 
                    }
                    cout << endl;
                }
           
               vOut.close();

        }