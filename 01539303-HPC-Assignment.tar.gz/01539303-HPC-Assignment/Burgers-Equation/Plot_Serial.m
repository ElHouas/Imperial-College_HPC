clear all:
%path='/home/ie3518/Documents/01539303-HPC-Assignment/Burgers-Equation/velocity_field.txt';
data=dlmread('velocity_field.txt');
x = data(:,1);
y = data(:,2);
U = data(:,3);
V = data(:,4);


[m,~] = size(U);
s=sqrt(m);
A=zeros(s);
B=zeros(s);
for i = 1:s-1
    for j = 1:s-1
        A(j,i) = U(j+s*i);
        B(j,i) = V(j+s*i);
    end
end

xx = (-5:10/s:4.99999);
yy = (-5:10/s:4.99999);
contourf(xx,yy,A)